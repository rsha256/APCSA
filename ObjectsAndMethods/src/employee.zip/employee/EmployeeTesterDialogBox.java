package employee;

import javax.swing.JOptionPane;

public class EmployeeTesterDialogBox {
	public static void main(String[] args) {
		// Input name as a String
		String name = JOptionPane.showInputDialog("What is the name of your employee?");
		// { complete implementation of EmployeeTesterDialogBox }
	}
}
package employee;

import java.util.Scanner;

public class EmployeeScanner {
	public static void main(String[] args) {
		System.out.println("Employee Class");
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter name: ");
		// { complete implementation of EmployeeScanner }
	}
}
